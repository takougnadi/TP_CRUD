import logo from './logo.svg';
import './App.css';
import React, { useState, useEffect} from "react"; 
import Axios from "axios";

function App() {

  const [bookName, setBookName] = useState('');
  const[review, setReview] = useState('');
  const [bookReviewList, setBookList]= useState([]);
  useEffect(()=>{
    Axios.get('http://localhost:3001/api/get').then((response)=>{
      console.log(response.data);
    });
  }, []);
  const submitReview = () => {
    Axios.post('http://localhost:3001/', {
      bookName:bookName, 
      bookReview: review,
    })//,then(()=>{
     // alert("successful insert");
    //})
  };
  return (
    <div className="App">
      <h1>CRUD</h1>
      <div className="form">
        <label>Book Name</label>
        <input 
          type="text" 
          name="bookName" 
          onChange={(e)=>
            setBookName(e.target.value)
          }
        />
        <label>Review Name</label>
        <input 
          type="text" 
          name="review"
          onChange={(e)=>
            setBookName(e.target.value)
          }
        />
        <button onClick={submitReview}>Submit</button>
        {bookReviewList.map((val)=>{
          return <h1>BookName: {val.bookName}</h1>
        })}
      </div>
    </div>
  );
}

export default App;
